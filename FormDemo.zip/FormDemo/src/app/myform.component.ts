import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Employee} from './employee.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{
    emp:Employee;
    empList:Employee[]=[];
    newEmpList:any[];
    constructor(private mser:Myservice){
        this.emp ={empNo:0,empName:"",salary:0,dept:""};
    }
    ngOnInit(){
        //this.empList= this.mser.getAllEmp();
        this.mser.getAllEmp().subscribe(result=>this.empList=result);
        this.mser.getFromSpring().subscribe(res=>this.newEmpList=res);
    }
    submitData(frm1:NgForm):void{
        let empno =frm1.controls['txtEmpNo'].value;
        let ename =frm1.controls['txtEmpName'].value;
        let sal =frm1.controls['txtSalary'].value;
        let dept =frm1.controls['txtDept'].value;
        let e = new Employee(empno,ename,sal,dept);
        this.empList.push(e);
    }
}