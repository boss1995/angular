import {Injectable} from '@angular/core';
import {Employee} from './employee.component'
import { Observable } from 'rxjs/Observable';
import {Http,Response} from '@angular/http';
import "rxjs/add/operator/map"
@Injectable()
export class Myservice {
    constructor(private http:Http){}
    
    getAllEmp():Observable<Employee[]>{
      return this.http.get('../assets/Emp.json')
          .map((res:Response)=><Employee[]>res.json());
  }
   
  getFromSpring():Observable<any>{
   return this.http.get('http://10.102.51.7:8081/SpringWithJpa/rest/employee')
     .map((res:Response)=><any[]>res.json());
  }  
}