"use strict";
var Employee = (function () {
    function Employee(empNo, empName, salary, dept) {
        this.empNo = empNo;
        this.empName = empName;
        this.salary = salary;
        this.dept = dept;
    }
    return Employee;
}());
exports.Employee = Employee;
