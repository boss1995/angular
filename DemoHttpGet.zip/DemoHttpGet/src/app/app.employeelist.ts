import {Component,OnInit} from '@angular/core';
import {IEmployee} from './employee';
import {EmployeeService} from './employee.service'
@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    providers:[EmployeeService]
})
export class EmployeeList implements  OnInit{
    
    employees:IEmployee[];
constructor(private empservice:EmployeeService) {
   
}
ngOnInit(): void {
    this.empservice.getAllEmployee().subscribe((employeeData)=>this.employees=employeeData);
}
    id1(){
        this.employees.sort(function(a,b){return a.id-b.id});
        }
           id2(){
        this.employees.sort(function(a,b){
            if(a.title<b.title)
            return -1;
        else if(a.title>b.title)   
            return 1;   
            else return 0;
        });
        }
          id4(){
        this.employees.sort(function(a,b){return a.year-b.year});
        
        
}
        }
    

