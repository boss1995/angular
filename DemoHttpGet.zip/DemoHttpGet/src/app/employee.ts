export interface IEmployee{
    id:number,
    title:string,
    author :string,
   year :number;
   

}