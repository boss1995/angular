<a name"1.0.1"></a>
### 1.0.1 (2016-06-26)


#### Features

* add node@6 compatability ([0579338f](https://github.com/karma-runner/karma-cli/commit/0579338f))


<a name"1.0.0"></a>
## 1.0.0 (2016-05-03)


<a name"0.1.2"></a>
### 0.1.2 (2015-12-23)


#### Bug Fixes

* Add node.js 5 to the engines list ([0acef9a6](https://github.com/karma-runner/karma-cli/commit/0acef9a6))


<a name"0.1.1"></a>
### 0.1.1 (2015-09-27)


#### Bug Fixes

* **engines:** use values from karma's engines requirement ([f7c492ce](https://github.com/karma-runner/karma-cli/commit/f7c492ce), closes [#13](https://github.com/karma-runner/karma-cli/issues/13))


<a name"0.1.0"></a>
## 0.1.0 (2015-06-26)


#### Bug Fixes

* Update node engine versions ([e2059aad](https://github.com/karma-runner/karma-cli/commit/e2059aad), closes [#11](https://github.com/karma-runner/karma-cli/issues/11), [#10](https://github.com/karma-runner/karma-cli/issues/10))
* return exit code ([0aad62e7](https://github.com/karma-runner/karma-cli/commit/0aad62e7))


<a name="v0.0.4"></a>
### v0.0.4 (2014-03-11)


#### Bug Fixes

* Use path.join() to make it run on Windows. ([05346293](http://github.com/karma-runner/karma-cli/commit/053462930de8bcdda800a425d66879df7b5b093f))

<a name="v0.0.3"></a>
### v0.0.3 (2013-11-18)


#### Features

* support Karma 0.10 ([2d7729e0](http://github.com/karma-runner/karma-cli/commit/2d7729e0fff8e5b795839d409dba26ece712bb3b))

<a name="v0.0.2"></a>
### v0.0.2 (2013-11-16)


#### Bug Fixes

* pass correct "basedir" option ([e81749e9](http://github.com/karma-runner/karma-cli/commit/e81749e940d7d75c3e019afa2cbd55f57991e8fe))

